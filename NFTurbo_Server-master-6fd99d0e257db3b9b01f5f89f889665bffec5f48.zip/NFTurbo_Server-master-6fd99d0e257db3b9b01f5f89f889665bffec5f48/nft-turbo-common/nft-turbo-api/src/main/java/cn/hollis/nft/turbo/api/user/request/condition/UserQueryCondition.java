package cn.hollis.nft.turbo.api.user.request.condition;

import java.io.Serializable;

/**
 * @author Hollis
 */
public interface UserQueryCondition extends Serializable {
}
