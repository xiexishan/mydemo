package cn.hollis.nft.turbo.api.pay.request;

/**
 * @author Hollis
 */
public interface PayQueryCondition {
}
