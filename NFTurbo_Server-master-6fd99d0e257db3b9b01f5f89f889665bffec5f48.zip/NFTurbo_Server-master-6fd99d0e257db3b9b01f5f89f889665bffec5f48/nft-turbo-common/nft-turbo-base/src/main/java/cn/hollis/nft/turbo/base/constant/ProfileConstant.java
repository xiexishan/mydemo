package cn.hollis.nft.turbo.base.constant;

/**
 * @author Hollis
 */
public class ProfileConstant {

    public static final String PROFILE_DEV = "dev";
}
